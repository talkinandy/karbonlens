# Handoff — KarbonLens

> **Push target:** https://github.com/talkinandy/karbonlens

## Overview

**KarbonLens** is an Indonesia-focused carbon market intelligence terminal. It reconciles data from SRN-PPI, IDXCarbon, Verra, Gold Standard, Sentinel (RADD / VIIRS / NDVI), and JDIH into a single workspace for developers, corporates, banks, and regulators.

The prototype is a 6-screen clickable design covering:

1. **Landing** (`#/`) — editorial light split-hero with a live satellite monitor
2. **Projects** (`#/projects`) — filterable registry table (214 indexed projects)
3. **Project detail** (`#/projects/:id`) — dossier with satellite MRV, score breakdown, VCU timeline, news
4. **Prices** (`#/prices`) — IDXCarbon snapshot, multi-series price chart, transactions
5. **Regulatory** (`#/regulatory`) — policy timeline (Permenhut 6/2026, Perpres 110/2025, etc.)
6. **Alerts** (`#/alerts`) — inbox with read/unread state + type filter

## About the Design Files

The files in `prototype/` are **design references written in HTML + inline React/JSX with Babel** — they exist to demonstrate the intended look, layout, typography, and interaction patterns. They are **not production code**.

Your job is to **recreate these designs in the target codebase's environment** using its established patterns and libraries. If no environment exists yet in the `talkinandy/karbonlens` repo, use your judgment — **Next.js 14 + TypeScript + Tailwind + shadcn/ui** is a strong default for this kind of data-dense marketing-plus-app hybrid; **Vite + React + TS + Tailwind** is an equally good choice if this is going to stay as a single-page prototype.

Every aesthetic decision — the Instrument Serif display type, the IBM Plex Mono labels, the cream surface palette, the editorial column rhythm, the dense data tables — is **intentional and must be preserved** unless the target codebase's design system demands otherwise.

## Fidelity

**High-fidelity (hifi).** Pixel-perfect mockups with final colors, typography, spacing, border treatments, and interaction states. Recreate pixel-perfectly.

---

## Tech stack recommendation

If starting fresh in `karbonlens`:

```
Next.js 14 (app router)   ← routing + SEO on the landing
TypeScript (strict)
Tailwind CSS              ← inline token parity with the CSS variables below
shadcn/ui                 ← base primitives (button, table, select, dialog)
Lucide React              ← icon set
Recharts                  ← price chart on /prices
```

Directory layout:

```
app/
├─ (marketing)/
│  └─ page.tsx                 ← landing
├─ (app)/
│  ├─ projects/
│  │  ├─ page.tsx              ← table
│  │  └─ [id]/page.tsx         ← detail
│  ├─ prices/page.tsx
│  ├─ regulatory/page.tsx
│  └─ alerts/page.tsx
├─ layout.tsx                  ← fonts + shell (topnav/footer)
└─ globals.css
components/
├─ shell/TopNav.tsx
├─ shell/Footer.tsx
├─ ui/{Pill,ScoreBadge,Tag}.tsx
├─ SatelliteMap.tsx            ← the big one — see below
├─ landing/{Hero,Ticker,Pipelines,FeaturedProjects,Roles,Methodology,Closer}.tsx
├─ project/{ScoreBreakdown,IssuanceChart,NewsFeed}.tsx
└─ prices/{PriceChart,TransactionsTable}.tsx
lib/
└─ mock-data.ts                ← port from prototype/data.js
```

---

## Design tokens

Port these into `tailwind.config.ts` (or `globals.css` as CSS variables):

### Colors

| Token | Hex | Use |
|---|---|---|
| `--bg` | `#FAFAF7` | Page background (cream) |
| `--surface` | `#FFFFFF` | Card backgrounds |
| `--surface-2` | `#F1EFE8` | Ticker band, stat cards, methodology section |
| `--border` | `rgba(0,0,0,0.08)` | Hairline dividers |
| `--border-strong` | `rgba(0,0,0,0.14)` | Buttons, inputs, active state |
| `--text` | `#1A1A1A` | Body text, headlines |
| `--text-2` | `#5F5E5A` | Secondary text |
| `--text-3` | `#888780` | Tertiary, uppercase labels |
| `--info-fg` | `#185FA5` | Links, info pill |
| `--info-bg` | `#E6F1FB` | Info pill background |
| `--success-fg` | `#0F6E56` | **Brand teal** — landing accent, score-high, boundary |
| `--success-bg` | `#E1F5EE` | Success pill background |
| `--warning-fg` | `#854F0B` | Warning pill |
| `--warning-bg` | `#FAEEDA` | Warning pill bg |
| `--danger-fg` | `#A32D2D` | Danger pill, reversal dot |
| `--danger-bg` | `#FCEBEB` | Danger pill bg |
| `--chart-blue` | `#378ADD` | IDTBS-RE price line |
| `--chart-teal` | `#1D9E75` | IDTBS price line, VCU bars |
| `--chart-amber` | `#BA7517` | IDNBS price line |
| `--chart-coral` | `#D85A30` | — |
| `--chart-red` | `#E24B4A` | RADD alert high-confidence |

Satellite-viewer-specific (dark):
| Token | Hex |
|---|---|
| Viewer bg | `#0F1411` |
| Toolbar bg | `#161B18` |
| Teal accent | `#4FB89C` (brighter teal on dark) |
| Alert red | `#E2625B` |
| Alert amber | `#F0B04E` |
| Fire orange | `#F28C28` |
| Community blue | `#8AB8E8` |

### Typography

Load from Google Fonts:
- **`Instrument Serif`** — weights 400, 400 italic. Used for **all display type** (hero H1, section H2s, stat values, featured card names, role titles).
- **`IBM Plex Sans`** — weights 400, 500, 600. Default body font (13px base).
- **`IBM Plex Mono`** — weights 400, 500. Used for eyebrows/kickers, uppercase labels, tabular values, chart axes, coordinates, monospace chips.

Scale:
| Role | Size / line-height / tracking | Family |
|---|---|---|
| Hero H1 | 84px / 0.96 / -2.2px | Instrument Serif 400 |
| Section H2 | 50px / 1.04 / -1.1px | Instrument Serif 400 |
| Methodology H | 54px / 1.1 / -1.2px | Instrument Serif 400 |
| Closer H | 56px / 1.06 / -1.2px | Instrument Serif 400 |
| Featured card name | 20px / 1.2 | Instrument Serif 400 |
| Stat value (big) | 32–72px | Instrument Serif 400 |
| Page title | 22px / 500 / -0.2px | IBM Plex Sans |
| Body | 13–17px | IBM Plex Sans |
| Eyebrow / label | 10–11px uppercase / 1–1.4px tracking | IBM Plex Mono |
| Tabular numerals | 12–18px | IBM Plex Mono + `font-variant-numeric: tabular-nums` |

### Spacing & radii

- Radii: `--radius-md: 8px`, `--radius-lg: 12px`, `--radius-xl: 16px`
- Hairlines: `0.5px solid` for all dividers (Retina-honest; fall back to `1px` gracefully)
- Gutters: landing sections use `max-width: 1320px; padding: 80px 32px`
- App pages use `max-width: 1200px; padding: 24px 24px 60px`
- Topnav height: **52px**, sticky, max-width 1200 inner

### Radius scale
| Token | px |
|---|---|
| `--radius-md` | 8 |
| `--radius-lg` | 12 |
| `--radius-xl` | 16 |

### No gradients, no drop-shadows, no emoji

The design deliberately avoids those. The only gradients that exist are **inside** the satellite-map SVG (NDVI ramp, terrain fill) — those are legitimate data visualization, not decorative chrome. **Don't add shadows to cards.** Elevation is communicated through `0.5px` borders only.

---

## Screens

### 1. Landing (`/`)

Shell is light (cream). Sections, in order:

1. **Hero** (`max-w-[1320px]`, 40px top / 32px side padding)
   - 2-col grid, `0.92fr : 1.08fr`, 48px gap
   - **Left:** kicker pill (mono 11px, teal dot), H1 three-line headline, English tagline, Bahasa tagline (Instrument Serif italic, muted), two buttons, stat row of 3 (Projects tracked / IDTBS-RE avg / VCUs traded YTD) above a hairline
   - **Right:** `<SatelliteMap mode="full" />` — the hero's visual anchor. See component spec below.

2. **Ticker** — full-width cream band, 6-column grid, each cell: mono 10px label, mono 17px value (tabular), mono 11px delta (colored up/down/flat).

3. **Pipelines** — 4-column grid of bordered cells (0.5px dividers between). Each cell: mono number (`01`–`04`) at top, Instrument Serif 22px title, **big Instrument Serif 42px teal stat**, mono label, body copy, mono "Explore →" CTA. Hover darkens to `--surface-2`.

4. **Featured projects** — 4-column card grid. Each card:
   - 16:9 thumbnail with an abstracted satellite SVG (dark green gradient, river polyline, teal boundary polygon, 2–3 colored alert dots)
   - Type chip overlay (mono, on dark scrim)
   - Body: Instrument Serif name, meta line, 3-col stat strip above a hairline (Score / Available / Registry)

5. **Built for** — 4-column bordered grid of roles (Developers / Corporates / Banks & VCs / Regulators). Mono number → Instrument Serif 26px title → body copy.

6. **Methodology** — full-width `--surface-2` (cream) band. Huge Instrument Serif 54px sentence with `<em>` teal + `<span class="fade">` muted color highlights. Below a hairline, 4-column stat strip using Instrument Serif 64px values.

7. **Closer** — centered 900px max, Instrument Serif 56px headline, subtitle, CTA pair.

(**No pricing section** — removed per user request.)

### 2. Projects (`/projects`)

- Page header: "Projects" / subtitle / Export CSV + Watchlist buttons
- Filter bar: search input + 3 selects (type / status / registry)
- Card-wrapped data table. Row: name + developer subtitle / type tag / province / hectares (right-aligned, tabular) / status pill / score badge / available (right-aligned) / registry chips (mono)
- Row hover → `--surface-2`; click → navigate to detail
- Count chip + "Click any row" helper in table header strip

### 3. Project detail (`/projects/:id`)

- Breadcrumb (`Projects / {name}`)
- Header: stack of status pill + type tag + registry tags → page title → meta line
- 4-column stat grid: Score / Issued / Retired / Available
- **Satellite monitoring** section — `<SatelliteMap mode="full" project={...} />`
- 2-column: Score breakdown (4 bars: validation / reversal / community / transparency) | VCU issuances by vintage (horizontal bar per year)
- News & signals feed (sentiment-colored left-border items)

### 4. Prices (`/prices`)

- Page header with range pills (`1M 3M 6M 1Y All`) + Export
- 4-stat grid: January value / Volume / Avg price / Participants
- Price chart card (SVG, 800×260 viewBox):
  - 5 horizontal gridlines every 10k (30k → 70k)
  - 3 series: IDTBS-RE blue, IDTBS teal, IDNBS amber (with a null gap mid-series)
  - 3px dots at each sample, 1.8px stroke, rounded join
  - Legend below chart
- Transactions table (Date / Market chip / Credit type (mono) / Project / Volume / Price)

### 5. Regulatory (`/regulatory`)

- Page header with importance select (all / critical / high / medium)
- Timeline: 160px date column + content column
  - Left: date (14px 500), status (mono uppercase), importance pill below
  - Right: Instrument Serif 15px 500 title, **italic** description, tag row
- Hairline between rows

### 6. Alerts (`/alerts`)

- Page header: "N unread" callout + "Mark all read" + "New alert rule"
- Type filter pill row (All / Reversal / Price / Regulatory / News / Retirement / Issuance) with counts
- Alert rows: unread-dot + severity pill + project tag + title + description + right-aligned time. Click toggles read.

---

## The SatelliteMap component

The centerpiece. Lives in `components/SatelliteMap.tsx`. Reusable across landing hero + project detail.

**Props:**
```ts
type SatelliteMapProps = {
  mode?: 'compact' | 'full';       // 'full' shows left layers panel
  project?: ProjectLike;           // centroid, alerts, hectares
}
```

**Structure:**
```
<div class="sat-viewer">
  <div class="sat-toolbar">
    <base-segmented: True color | NDVI | Sentinel-1>
    <opacity slider (full only)>
    <mono chips: "Sentinel-2 L2A" · "10 m / px">
  </div>
  <div class="sat-stage grid-cols-[220px_1fr] (or 1fr in compact)">
    <aside class="sat-layers">            ← full mode only
      Observation:      Project boundary, Graticule
      Deforestation:    RADD alerts, GFW loss, VIIRS hotspots
      Social:           Community points
      <meta footer>     Centroid, Acquired, Cloud cover, Provider
    </aside>
    <div class="sat-map-wrap">
      <svg viewBox="0 0 800 520">
        <defs>
          <linearGradient id="truecolorGrad">...</linearGradient>
          <linearGradient id="ndviGrad">red→yellow→green</linearGradient>
          <linearGradient id="radarGrad">grayscale</linearGradient>
          <linearGradient id="riverGrad">blue</linearGradient>
          <pattern id="peatPattern">stipple dots</pattern>
          <clipPath id="clipBoundary"><path d={boundary}/></clipPath>
          <radialGradient id="alertGlow">red glow</radialGradient>
          <radialGradient id="fireGlow">orange glow</radialGradient>
        </defs>
        <rect base fill={current-base-gradient} opacity={opacity}/>
        {truecolor && [scattered dark blobs for terrain]}
        <path river curve d="..." stroke=riverGrad/>
        {truecolor && <g clipPath=clipBoundary>[peat stipple + cleared ellipses]</g>}
        {layers.graticule && [faint lines]}
        {layers.boundary && [buffer ring dashed, boundary polygon solid]}
        {layers.radd && [5 tree-cover loss rectangles]}
        {layers.hotspots && [fire dots with radial glow]}
        {layers.alerts && [pulsing RADD dots with animate attributeName='r']}
        {layers.community && [blue squares with mono labels]}
        <reticle crosshair at 380,270/>
        <scalebar bottom-right: 0 — 5 — 10 km/>
        <north-arrow top-left/>
      </svg>
      <div class="sat-hud">Observation · live / title / sub</div>
      {callout && <popover on last clicked alert>}
      <div class="sat-legend">RADD high / RADD nominal / Boundary / Fire</div>
    </div>
  </div>
  <footer class="sat-footer">ESA Copernicus · Sentinel-2 · WUR RADD · GFW | 1°48′03.4″S · 113°12′47.1″E · UTM 49S</footer>
</div>
```

**Interactions:**
- Base toggle swaps the base gradient (true-color peat palette / NDVI red-yellow-green / Sentinel-1 grayscale)
- Legend changes when NDVI base is active (shows NDVI ramp -0.2 → +0.9)
- Opacity slider controls `<rect opacity>` of the base fill
- Layer toggles in left panel hide/show the corresponding SVG group
- Clicking any RADD alert dot opens the `.sat-callout` popover (positioned at dot + 30,−80, clamped to canvas) showing area / date / source / inside-polygon flag
- Alert dots use SVG `<animate>` for the pulse (r 14→26→14, opacity 0.9→0.2→0.9, 2.4s loop)

**Reference implementation:** `prototype/src/SatelliteMap.jsx` (450 lines). Port as-is to TSX; the SVG structure and gradient definitions are the design.

---

## Mock data

`prototype/data.js` defines `window.KL_DATA`:

- `projects` — 10 projects (Katingan, Sumatra Merang, Muara Teweh, Pesisir Biru, Rimba Raya, Pertamina Lahendong, PLTGU Muara Karang, PLTM Gunung Wugul, Cendrawasih Aru, Bukit Tigapuluh). Full shape includes `id, name, shortName, developer, type, province, provinceShort, hectares, centroid, status, score, breakdown {validation,reversal,community,transparency}, issued, retired, available, lastVintage, registries[], registriesShort, issuances[{year,value}], alerts[{x,y,conf}], news[{sentiment,title,source,daysAgo}]`
- `priceStats` — Jan value/volume/avg/participants
- `priceSeries` — 6-month multi-line data (IDTBS-RE, IDTBS, IDNBS)
- `transactions` — 4 recent trades
- `regulatory` — 7 policy items (Permenhut 6/2026 is the headliner)
- `alerts` — 7 inbox items with type, severity, read state

Port this to `lib/mock-data.ts` with proper TypeScript types. Keep every field — the UI references all of them.

---

## Routing + persistence

- **Hash routing** in the prototype (`#/`, `#/projects`, `#/projects/:id`, `#/prices`, `#/regulatory`, `#/alerts`). Port to Next.js app router (each becomes a folder under `app/`).
- Last route is persisted to `localStorage['kl_last_route']`. In Next.js this is redundant with URL state, so **drop it**.
- Projects filters (search / type / status / registry) are local state — no persistence required.
- Alerts read state is local state on the page (no backend). If a future task wires persistence, use `localStorage['kl_alerts_read']: number[]`.

---

## Interactions & behavior

| Location | Trigger | Effect |
|---|---|---|
| Topnav logo | click | `router.push('/')` |
| Topnav nav links | click | route change; active link gets `bg-surface-2` |
| Topnav bell | click | `router.push('/alerts')` |
| Featured card (landing) | click | route to `/projects/:id` |
| Pipeline card (landing) | click | route to target (projects / prices / regulatory / project detail) |
| Projects table row | click | route to `/projects/:id` |
| Projects filters | change | filter table in-place (client) |
| Price range pills | click | swap chart window (data is static — just toggle `active` class for now) |
| Regulatory importance select | change | filter timeline |
| Alerts type pills | click | filter list |
| Alert row | click | toggle `read` flag |
| Alerts "Mark all read" | click | set all `read: true` |
| SatelliteMap base segmented | click | swap base SVG fill |
| SatelliteMap layer toggle | click | flip layer visibility |
| SatelliteMap opacity slider | drag | set base-rect opacity |
| SatelliteMap alert dot | click | open `.sat-callout` popover |
| SatelliteMap callout × | click | close popover |

No transitions longer than **150ms**. No animations except the RADD alert pulse (2.4s loop).

---

## State

- **Global-ish (context or server component):** the mock-data module is imported directly. No fetch layer yet.
- **Page-local React state:**
  - `Landing`: none (pure render)
  - `Projects`: `{ q, type, status, registry }`
  - `ProjectDetail`: none (pure render from project-by-id)
  - `Prices`: `{ range }`
  - `Regulatory`: `{ filter }`
  - `Alerts`: `{ alerts, filter }` (derived `unread` count)
  - `SatelliteMap`: `{ base, layers, callout, opacity }`

---

## Content / copy

Do not paraphrase. The exact English + Bahasa copy is part of the design. Reference `prototype/src/Landing.jsx` for hero tagline wording, pipeline bodies, role bodies, methodology phrasing, and closer text.

---

## Responsive

- `max-width: 1100px`: hero stacks single-column, pipeline/featured/roles grids collapse to 2 columns, type sizes shrink (H1 → 60px, H2 → 38px)
- `max-width: 640px`: everything collapses to single column, type sizes shrink again (H1 → 40px)
- `max-width: 768px`: topnav hides its middle links, page padding drops to 16px
- All tables should remain horizontally scrollable on mobile (wrap in `<div class="overflow-x-auto">`)

---

## Assets

No image assets. Every visual is either SVG-generated inline (satellite map, featured card thumbnails, brand mark) or pure CSS/type. The teal logo mark is:

```svg
<svg viewBox="0 0 14 14">
  <circle cx="7" cy="7" r="5.3" stroke="currentColor" stroke-width="1.2" fill="none"/>
  <circle cx="7" cy="7" r="1.8" fill="currentColor"/>
</svg>
```

Fonts ship from Google Fonts — add to `<head>` (or `next/font/google`):

```
<link href="https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=IBM+Plex+Sans:wght@400;500;600&family=IBM+Plex+Mono:wght@400;500&display=swap" rel="stylesheet" />
```

---

## Files in this bundle

- `prototype/index.html` — the entry with script tags (React + Babel in-browser)
- `prototype/styles.css` — **1105 lines of CSS — the source of truth for all styling.** Read this file end-to-end.
- `prototype/data.js` — mock data
- `prototype/src/` — 9 JSX files:
  - `shared.jsx` — router hook, TopNav, Shell, Pill, ScoreBadge, Tag, helpers
  - `SatelliteMap.jsx` — the big one
  - `Landing.jsx`
  - `Projects.jsx`
  - `ProjectDetail.jsx`
  - `Prices.jsx`
  - `Regulatory.jsx`
  - `Alerts.jsx`
  - `App.jsx` — hash router

Open `prototype/index.html` locally (or via `python -m http.server`) to see the live prototype before you start porting.

---

## Push-to-repo checklist

Once implemented in the real stack:

1. `git clone git@github.com:talkinandy/karbonlens.git`
2. Initialize framework of choice (`npx create-next-app@latest karbonlens --typescript --tailwind --app`)
3. Configure fonts, Tailwind tokens (from Design tokens section above)
4. Build shell (TopNav + Footer) → implement light theme + serif display type
5. Build `SatelliteMap` component first (it's used by 2 screens and blocks hero)
6. Port screens in order: Landing → Projects → ProjectDetail → Prices → Regulatory → Alerts
7. Seed mock data in `lib/mock-data.ts`
8. `pnpm dev` → visual QA against `prototype/index.html`
9. Commit with conventional commits, PR to `main`

Good luck — this design leans heavily on restraint. When in doubt, **remove**, don't add.
